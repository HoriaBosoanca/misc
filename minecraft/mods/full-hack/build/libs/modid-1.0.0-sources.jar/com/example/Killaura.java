package com.example;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

public class Killaura implements ClientModInitializer {

    private boolean killAuraIsOn = false;
    private class_304 killAuraKey;

    private final float MAX_ATTACK_RANGE = 4.0f;

    private int tickNumber = 0;
    private final int TICK_DELAY = 0;

    @Override
    public void onInitializeClient() {
        killAuraKey = KeyBindingHelper.registerKeyBinding(new class_304("key.killAura.toggle", GLFW.GLFW_KEY_F9, "category.killAura"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (killAuraKey.method_1436()) {
                killAuraIsOn = !killAuraIsOn;
            }
            if (killAuraIsOn && client.field_1724 != null && client.field_1687 != null) {
                for (class_1297 entity : client.field_1687.method_18112()) {
                    try {
                        if (isValidEntity(entity, client)) {
                            if (tickNumber == TICK_DELAY) {
                                tickNumber = 0;
                                faceEntity(client.field_1724, entity);
                                client.field_1761.method_2918(client.field_1724, entity);
                                client.field_1724.method_6104(client.field_1724.method_6058());
                            } else {
                                tickNumber++;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    private boolean isValidEntity(class_1297 entity, class_310 client) {
        return entity != client.field_1724 && entity.method_5805() && !entity.method_31481() && entity.method_5709() && client.field_1724.method_6057(entity) && entity instanceof class_1657 && client.field_1724.method_5739(entity) <= MAX_ATTACK_RANGE;
    }

    private void faceEntity(class_746 player, class_1297 target) {
        double dx = target.method_23317() - player.method_23317();
        double dy = target.method_23320() - player.method_23320();
        double dz = target.method_23321() - player.method_23321();
        double distance = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) (Math.atan2(dz, dx) * 180 / Math.PI - 90);
        float pitch = (float) -(Math.atan2(dy, distance) * 180 / Math.PI);

        player.method_36456(yaw);
        player.method_36457(pitch);
    }
}

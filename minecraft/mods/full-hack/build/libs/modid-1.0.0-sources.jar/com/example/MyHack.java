package com.example;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_5134;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

public class MyHack implements ClientModInitializer {

	private class_304 speedBoostKey;
	private class_304 jumpBoostKey;
	private class_304 reachBoostKey;

	private boolean speedIsOn = false;
	private boolean jumpIsOn = false;
	private boolean reachIsOn = false;

	@Override
	public void onInitializeClient() {

		speedBoostKey = KeyBindingHelper.registerKeyBinding(new class_304("key.myHack.speedBoost", GLFW.GLFW_KEY_F6, "category.myHack"));
		jumpBoostKey = KeyBindingHelper.registerKeyBinding(new class_304("key.myHack.jumpBoost", GLFW.GLFW_KEY_F7, "category.myHack"));
		reachBoostKey = KeyBindingHelper.registerKeyBinding(new class_304("key.myHack.reachBoost", GLFW.GLFW_KEY_F8, "category.myHack"));

		ClientTickEvents.START_WORLD_TICK.register(client -> {
			if (class_310.method_1551().field_1724 != null) {
				class_746 player = class_310.method_1551().field_1724;

				// speed:
				if (speedBoostKey.method_1436()) {
					speedIsOn = !speedIsOn;
				}
				if (speedIsOn) {
					player.method_5996(class_5134.field_23719).method_6192(0.3);
				} else {
					player.method_5996(class_5134.field_23719).method_6192(0.1);
				}

				// jump boost:
				if (jumpBoostKey.method_1436()) {
					if (!jumpIsOn) {
						jumpIsOn = true;
						player.method_5996(class_5134.field_23728).method_6192(0.7);
					} else {
						jumpIsOn = false;
						player.method_5996(class_5134.field_23728).method_6192(0.4);
					}
				}

				// reach (Both for attack and blocks by 1 block - which is the max):
				if (reachBoostKey.method_1436()) {
					if (!reachIsOn) {
						reachIsOn = true;
						player.method_5996(class_5134.field_47759).method_6192(6);
						player.method_5996(class_5134.field_47758).method_6192(6);
					} else {
						reachIsOn = false;
						player.method_5996(class_5134.field_47759).method_6192(3);
						player.method_5996(class_5134.field_47758).method_6192(4.5);
					}
				}

				// flight:
				player.method_31549().field_7478 = true;

				// TODO:
				// safeTP
				// killaura
			}
		});
	}
}
